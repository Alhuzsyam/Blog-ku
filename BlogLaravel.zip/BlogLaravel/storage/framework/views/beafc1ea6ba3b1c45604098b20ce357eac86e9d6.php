<?php $__env->startSection('login_form'); ?>


<div class="col-lg-6 fback mt-5">
    <form action="/loginpost" method="post" class="mt-5">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('statuscek')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('statuscek')); ?>

        </div>
        <?php endif; ?>
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="form-group mb-3">
                <input type="email" name="email" id="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="type your email" aria-describedby="helpId">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                
                <input type="password" name="password" id="password" class="form-control  <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" aria-describedby="helpId">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <small id="helpId" class="text-muted" style="float: right">Recovery Password</small>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-md" style="width: 16.5rem">Login</button>
            </div>
            <div class="col-md">
                <div class="line"></div>
                <div class="col-md" style="float:right">
                    <a class="btn btn-danger btn-md btn-block"><i class='bx bxl-google'></i> Google</a>
                    <a class="btn btn-primary btn-md btn-block"><i class='bx bxl-twitter' ></i> Twitter</a>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/auth/login.blade.php ENDPATH**/ ?>