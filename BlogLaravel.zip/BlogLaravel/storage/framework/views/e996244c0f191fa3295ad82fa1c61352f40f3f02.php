<?php $__env->startSection('title',"BlogKu Office"); ?>




<?php $__env->startSection('container'); ?>
<div class="home_content continer mscroll">
    <?php if(session('status')): ?>
    
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Alert</strong> <?php echo e(session('status')); ?>.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>
    <div class="row">
       <div class="col-md-12 p-5 mt-0">
            
            <div class="jumbotron jumbotron-fluid" style="background: url('/assets/img/banner.png'); border-radius:0px">
                <div class="container">
                  <h2 class="display-5"><?= $title ?></h1>
                  <p class="lead">Focuse on being productive instead of busy</p>
                </div>
              </div>
             <form action="/content/write" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('POST')); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Judul</label>
                          <input type="text" name="judul" id="judul" class="form-control <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="" aria-describedby="helpId">
                          <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                          <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                          <label for="">Deskripsi</label>
                          <input type="text" name="deskripsi" id="deskripsi" class="form-control <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="" aria-describedby="helpId">
                          <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?>
                          <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class='bx bx-image-add bx-sm'></i></span>
                            </div>
                            <div class="custom-file">
                              <input type="file" name="file" class="custom-file-input <?php if ($errors->has('file')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('file'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="inputGroupFile01">
                              <label class="custom-file-label" for="inputGroupFile01">Choose file </label>
                            </div>
                            <?php if ($errors->has('file')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('file'); ?>
                            <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                          </div>
                    </div>
                </div>
                <div class="row">
                   <div class="col-md-12">
                       <div class="form-group">
                           <label for="exampleFormControlTextarea1">write the content</label>
                           <textarea name="content" id="mytextarea" class="form-control rounded-0 form-control <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="exampleFormControlTextarea1" rows="10"></textarea>
                           <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
                           <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                       </div>   
                   </div>
                </div>
                <div class="row col-md-4">
                    <button class="btn btn-primary btn-sm"><i class='bx bx-pointer'></i> POST</button>
                </div>
             </form>
       </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/admin/content.blade.php ENDPATH**/ ?>