<?php $__env->startSection('login_form'); ?>
<div class="col-md-7">
    <div class="d-flex align-items-center p-5 mt-5">
        <div class="container">
            <div class="col-lg-10 col-xl-7 mx-auto">
                <div class="h2 logo_name textwhite">Login Form</div>
                
                <form action="/loginpost" method="post" class="mt-5">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session('statuscek')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('statuscek')); ?>

                    </div>
                    <?php endif; ?>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                      <label for=""></label>
                      <input type="email" name="email" id="email" class="form-control  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="type your email" aria-describedby="helpId">
                      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                      <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                      <label for=""></label>
                      <input type="password" name="password" id="password" class="form-control   <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" aria-describedby="helpId">
                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                      <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      <small id="helpId" class="text-muted mt-2" style="float: right">Recovery Password</small>
                    </div>
                    <div class="mt-5">
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary border-0" type="button">Login</button>
                        </div>
                    </div>
                    <div class="line">
                    </div>
                    <div class="mt-3">
                        <div class="d-grid gap-2">
                            <button class="btn btn-danger" type="button">Google</button>
                            <button class="btn btn-primary" type="button">Twitter</button>
                          </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth2/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/auth2/login.blade.php ENDPATH**/ ?>