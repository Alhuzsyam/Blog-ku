<?php $__env->startSection('login_form'); ?>
<div class="col-lg-6 fback mt-5">
    <form action="/register" method="post" class="mt-5">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="form-group mb-3">
                
                <input type="email" name="email" id="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="type your email" aria-describedby="helpId">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group mb-3">
                
                <input type="text" name="name" id="name" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="input your name" aria-describedby="helpId">
                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="container mb-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            
                            <input type="password" name="password" id="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" aria-describedby="helpId">
                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            
                            <input type="password" name="password2" id="password2" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="confirm password" aria-describedby="helpId">
                            <?php if ($errors->has('password2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password2'); ?>
                            <small id="helpId" class="invalid-feedback"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-md" style="width: 16.5rem">Register</button>
            </div>
            <div class="col-md">
                <div class="line"></div>
                <div class="col-md" style="float:right">
                    <a class="btn btn-danger btn-md btn-block"><i class='bx bxl-google'></i> Google</a>
                    <a class="btn btn-primary btn-md btn-block"><i class='bx bxl-twitter' ></i> Twitter</a>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/auth/register.blade.php ENDPATH**/ ?>