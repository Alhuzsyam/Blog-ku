# DOCKER CONFIG FOR LARAVEL

Root folder information

```

LARAVEL
|-- app.dockerfile
|-- web.dockerfile
|-- laravelVHost.conf
|-- docker-compose.yml
|-- app
|-- resources
|-- And the other.....


```

## automatic create a image for app (source code image) & web (webserver config image)

```
 $ docker-compose up -d 

```
